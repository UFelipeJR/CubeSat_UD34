*PADS-LIBRARY-PART-TYPES-V9*

TPS3851H33EDRBR TVS3301DRBR I ANA 9 1 0 0 0
TIMESTAMP 2026.10.26.04.15.47
"Manufacturer_Name" Texas Instruments
"Manufacturer_Part_Number" TPS3851H33EDRBR
"Mouser Part Number" 
"Mouser Price/Stock" 
"Arrow Part Number" TPS3851H33EDRBR
"Arrow Price/Stock" https://www.arrow.com/en/products/tps3851h33edrbr/texas-instruments.html?utm_currency=USD&region=europe
"Description" TPS3851 Precision Voltage Supervisor with Integrated Watchdog Timer
"Datasheet Link" https://www.ti.com/lit/ds/symlink/tps3851.pdf?ts=1710748456987&ref_url=https%253A%252F%252Fwww.ti.com.cn%252Fproduct%252Fzh-cn%252FTPS3851%253FkeyMatch%253DTPS3851%2526tisearch%253Dsearch-everything%2526usecase%253DGPN-ALT
"Geometry.Height" 1mm
GATE 1 13 0
TPS3851H33EDRBR
1 0 U VDD
2 0 U CWD
3 0 U \MR
4 0 U GND
5 0 U SET1
6 0 U WDI
7 0 U \WDO
8 0 U \RESET
9 0 U EP_1
10 0 U EP_2
11 0 U EP_3
12 0 U EP_4
13 0 U EP_5

*END*
*REMARK* SamacSys ECAD Model
19290390/2201071/2.50/13/4/Integrated Circuit
