*PADS-LIBRARY-PART-TYPES-V9*

ECS-240-8-33Q-JES-TR ECS240833QJESTR I OSC 9 1 0 0 0
TIMESTAMP 2026.10.19.03.39.59
"Manufacturer_Name" ECS
"Manufacturer_Part_Number" ECS-240-8-33Q-JES-TR
"Mouser Part Number" 520-240-8-33Q-JEST
"Mouser Price/Stock" https://www.mouser.co.uk/ProductDetail/ECS/ECS-240-8-33Q-JES-TR?qs=wd5RIQLrsJjAK9TRoK5p0w%3D%3D
"Arrow Part Number" ECS-240-8-33Q-JES-TR
"Arrow Price/Stock" https://www.arrow.com/en/products/ecs-240-8-33q-jes-tr/ecs-international
"Description" Crystals 24MHz 20ppm 8pF -40C +125C
"Datasheet Link" https://www.arrow.com/en/products/ecs-240-8-33q-jes-tr/ecs-international
"Geometry.Height" 0.8mm
GATE 1 4 0
ECS-240-8-33Q-JES-TR
1 0 U IN/OUT
2 0 U GND_1
3 0 U OUT/IN
4 0 U GND_2

*END*
*REMARK* SamacSys ECAD Model
1281018/2201071/2.50/4/4/Crystal or Oscillator
